/*
 * AppDelegate
 * This is a singleton class
 * @category   PhotosApp
 * @package    com.PhotosApp
 * @version    1.0
 * @author     ssowri1
 * @copyright  Copyright (C) 2018 ssowri1. All rights reserved.
 */
import UIKit
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }
}
