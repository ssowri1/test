/*
 * CSPhotosViewController
 * This SPPhotosViewController is main class to control all the operations
 * @category   PhotosApp
 * @package    com.PhotosApp
 * @version    1.0
 * @author     ssowri1
 * @copyright  Copyright (C) 2018 ssowri1. All rights reserved.
 */
import UIKit
class SPPhotosViewController: UIViewController {
    @IBOutlet weak var scrollView: SPScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollView.viewFrame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        scrollView.images = [#imageLiteral(resourceName: "snapOne"), #imageLiteral(resourceName: "snapTwo"), #imageLiteral(resourceName: "snapThree"), #imageLiteral(resourceName: "snapFour"), #imageLiteral(resourceName: "snapFive"), #imageLiteral(resourceName: "snapSix"), #imageLiteral(resourceName: "snapSeven"), #imageLiteral(resourceName: "snapEight"), #imageLiteral(resourceName: "snapNine"), #imageLiteral(resourceName: "snapTen")]
    }
}
